package Test;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSON;
import net.sf.json.JSONSerializer;

import org.json.*;

public class test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
        //调用接口
		//SelectOne();//查询单条业务数据
		// SelectMore();批量查询业务数据
		// CreateBusinessData();//创建单条业务数据
		// CreateBusinessDatas();//批量创建业务数据
		// UpdateBusinessData();//更新业务数据
		// DeleteBusinessDate();//删除业务数据
		// SendPostUplodFile("C:\\Users\\authine\\Desktop\\1.png");//上传文件
		//DownUrlPost();// 下载文件
		//SelectUser();查询自定义接口
	}

	/* 查询单条业务数据 */
	public static void SelectOne() {
		// 配置请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "LoadBizObject");
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584");
		paramMap.put("BizObjectId", "a073e93e-7961-4390-a1bd-736c3bebbe1f");
		String select = JSONObject.valueToString(paramMap);
		doPost("https://www.h3yun.com/OpenApi/Invoke", select);
	}

	/* 批量查询业务数据 */
	public static void SelectMore() {
		// 配置请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "LoadBizObjects");// 调用的方法名
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584"); // 需要查询的表单编码
		// 过滤条件。默认返回前500条数据
		// FromRowNum分页查询，从第几条开始
		// RequireCount查询的总行数
		// ReturnItems返回的字段，不填返回所有
		// SortByCollection排序字段，目前不支持使用，默认置空
		// ToRowNum分页查询，第几条结束
		// Matcher查询条件
		paramMap.put("Filter",
				"{\"FromRowNum\":0," + "\"RequireCount\": false," + "\"ReturnItems\": [],   "
						+ "\"SortByCollection\": []," + "\"ToRowNum\": 500,   "
						+ "\"Matcher\": { \"Type\": \"And\",   \"Matchers\": [{'F0000001':122}]}}");
		String select = JSONObject.valueToString(paramMap);
		doPost("https://www.h3yun.com/OpenApi/Invoke", select);
	}

	/* 创建单条业务数据 */
	public static void CreateBusinessData() {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "CreateBizObject");// 调用的方法名
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584"); // 表单编码
		paramMap.put("BizObject", "{\"F0000001\":\"添加数据测试\",\"F0000002\":\"ctes\"}");// BizObject对象的json 字符串
		// 例如：F0000001为表单里面的控件id
		paramMap.put("IsSubmit", "false");// 为true时创建生效数据，false 为草稿数据 默认为false
		String CreateStr = JSONObject.valueToString(paramMap);
		// 请求接口
		doPost("https://www.h3yun.com/OpenApi/Invoke", CreateStr);
	}

	/* 批量创建业务数据 */
	public static void CreateBusinessDatas() {
		// 添加请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "CreateBizObjects");// 调用的方法名
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584"); // 表单编码

		List<String> Childerdd = new ArrayList<String>();// BizObject[]对象的 成员
		Childerdd.add("{\"F0000001\":\"ceee002229\",\"F0000002\":\"ctes5\"}");
		Childerdd.add("{\"F0000001\":\"cesd00099222\",\"F0000002\":\"ctes6\"}");
		paramMap.put("BizObjectArray", Childerdd.toArray());// BizObject[]对象的json数组
		// 例如：F0000001为表单里面的控件id
		paramMap.put("IsSubmit", "false");// 为true时创建生效数据，false 为草稿数据 默认为false
		String CreateStr = JSONObject.valueToString(paramMap);
		// 请求接口
		doPost("https://www.h3yun.com/OpenApi/Invoke", CreateStr);

	}

	/* 更新业务数据 */
	public static void UpdateBusinessData() {
		// 添加请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "UpdateBizObject");// 调用的方法名
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584"); // 表单编码
		paramMap.put("BizObjectId", "8861e21d-57a0-46c9-bf7d-960309163bff"); // 表单ObjectId值
		paramMap.put("BizObject", "{\"F0000001\":\"TS-000322\",\"F0000002\":\"cte1s\"}");// BizObject对象的json 字符串
																							// 即需要修改的数据的控件id和值
		String UpdateStr = JSONObject.valueToString(paramMap);
		// 请求接口
		doPost("https://www.h3yun.com/OpenApi/Invoke", UpdateStr);
	}

	/* 删除业务数据 */
	public static void DeleteBusinessDate() {
		// 添加请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("ActionName", "RemoveBizObject");// 调用的方法名
		paramMap.put("SchemaCode", "D0015994821985e8b434394bc0737ffb22a0584"); // 表单编码
		paramMap.put("BizObjectId", "46961303-6fcf-486b-9260-dcaacf1b5802"); // 表单ObjectId值
		String DeleteStr = JSONObject.valueToString(paramMap);
		// 请求接口
		doPost("https://www.h3yun.com/OpenApi/Invoke", DeleteStr);
	}

	// 上传文件
	/// in11 要上传文件的路径
	public static String SendPostUplodFile(String in11) {
		DataOutputStream out = null;// 定义输出流
		BufferedReader in = null;
		String result = "";
		try {
			// URL realUrl = new
			// URL("http://file.kgfuns.com/fileserver/upload?BusiessId=23");
			URL realUrl = new URL(
					"https://www.h3yun.com/OpenApi/UploadAttachment?SchemaCode=D0015994821985e8b434394bc0737ffb22a0584&FilePropertyName=F0000005&BizObjectId=99491c28-05b1-44b0-8a42-fd139b113ab0");
			// 打开和URL之间的连接
			HttpURLConnection conn = (HttpURLConnection) realUrl.openConnection();

			// 构建请求头
			String BOUNDARY = "----WebKitFormBoundary07I8UIuBx6LN2KyY";
			conn.setUseCaches(false);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("connection", "Keep-Alive");
			// conn.setRequestProperty("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64;
			// x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100
			// Safari/537.36");
			conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			conn.setRequestProperty("Charsert", "UTF-8");
			conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);
			// 必须要有的身份认证参数 在组织 界面 钉钉右上角 我的头像点击 后 系统管理》系统集成中有这两个字段
			conn.setRequestProperty("EngineCode", "fs1tkeu2ap4kb4hp");
			conn.setRequestProperty("EngineSecret", "Ed0JouQbydoe1seTTuETeqK7VbJqTX2jEWOUCnnfgZc0kzLg18nZFw==");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.connect();

			// 设置输出流
			out = new DataOutputStream(conn.getOutputStream());

			// 添加参数file
			File file = new File(String.valueOf(in11));
			StringBuffer sb = new StringBuffer();
			sb.append("--");
			sb.append(BOUNDARY);
			sb.append("\r\n");
			// 媒体类型上传的类型
//sb.append("Content-Disposition: form-data; name=\"media\";filename=\"").append(fileName).append(typeName);
//（Instream）流文件上传的时候要指定filename的值
			sb.append("Content-Disposition: form-data;name=\"file_data\";filename=\"" + file.getName() + "\"");
			sb.append("\r\n");
			sb.append("Content-Type: application/octet-stream");
			sb.append("\r\n");
			sb.append("\r\n");
			// 发送请求参数即数据
			out.write(sb.toString().getBytes());

			FileInputStream in1 = new FileInputStream(file);
			int bytes = 0;
			byte[] bufferOut = new byte[1024];
			while ((bytes = in1.read(bufferOut)) != -1) {
				out.write(bufferOut, 0, bytes);
			}
			out.write("\r\n".getBytes());
			in1.close();

			byte[] end_data = ("\r\n--" + BOUNDARY + "--\r\n").getBytes();
			out.write(end_data);
			out.flush();// flush输出流的缓冲
			/**
			 * 下面的代码相当于，获取调用第三方http接口后返回的结果
			 */
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public static void DownUrlPost() {

		DownHelp d = new DownHelp();
		// 添加请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("attachmentId", "9ed357b1-a01a-460b-b0dd-8d9cb789e296");
		paramMap.put("EngineCode", "fs1tkeu2ap4kb4hp");
		String Down = JSONObject.valueToString(paramMap);
		// 请求接口
		d.getInternetResdoPost("https://www.h3yun.com/Api/DownloadBizObjectFile", Down);
	}

	//自定义接口 查询用户信息
	public static void SelectUser() 
	{
		// 配置请求参数
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("ActionName", "SelectUser");
				paramMap.put("AppCode", "D001599BookManager");//应用编码
				paramMap.put("Controller", "MyApiController");//类名称
				paramMap.put("UserName", "lmz");//请求条件
				String select = JSONObject.valueToString(paramMap);
				doPost("https://www.h3yun.com/OpenApi/Invoke", select);
		
	}
	
	
	/**
	 * 以post方式调用对方接口方法
	 * 
	 * @param pathUrl
	 */
	public static void doPost(String pathUrl, String data) {
		OutputStreamWriter out = null;
		BufferedReader br = null;
		String result = "";
		try {
			URL url = new URL(pathUrl);

			// 打开和url之间的连接
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			// 设定请求的方法为"POST"，默认是GET
			// post与get的不同之处在于post的参数不是放在URL字串里面，而是放在http请求的正文内。
			conn.setRequestMethod("POST");

			// 设置30秒连接超时
			conn.setConnectTimeout(30000);
			// 设置30秒读取超时
			conn.setReadTimeout(30000);

			// 设置是否向httpUrlConnection输出，因为这个是post请求，参数要放在http正文内，因此需要设为true, 默认情况下是false;
			conn.setDoOutput(true);
			// 设置是否从httpUrlConnection读入，默认情况下是true;
			conn.setDoInput(true);

			// Post请求不能使用缓存
			conn.setUseCaches(false);

			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive"); // 维持长链接
			conn.setRequestProperty("Content-Type", "application/json;charset=utf-8");
			// 必须要有的身份认证参数 在组织 界面 钉钉右上角 我的头像点击 后 系统管理》系统集成中有这两个字段
			conn.setRequestProperty("EngineCode", "fs1tkeu2ap4kb4hp");
			conn.setRequestProperty("EngineSecret", "Ed0JouQbydoe1seTTuETeqK7VbJqTX2jEWOUCnnfgZc0kzLg18nZFw==");

			// 连接，从上述url.openConnection()至此的配置必须要在connect之前完成，
			conn.connect();

			/**
			 * 下面的三句代码，就是调用第三方http接口
			 */
			// 获取URLConnection对象对应的输出流
			// 此处getOutputStream会隐含的进行connect(即：如同调用上面的connect()方法，所以在开发中不调用上述的connect()也可以)。
			out = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
			// 发送请求参数即数据
			out.write(data);
			// flush输出流的缓冲
			out.flush();

			/**
			 * 下面的代码相当于，获取调用第三方http接口后返回的结果
			 */
			// 获取URLConnection对象对应的输入流
			InputStream is = conn.getInputStream();
			StringBuilder json = new StringBuilder();
			// 构造一个字符流缓存
			br = new BufferedReader(new InputStreamReader(is));
			String str = "";
			while ((str = br.readLine()) != null) {
				result += str+ "\r\n";;
				json.append(str +  "\r\n");
			}
			while((str = br.readLine())!=null){
				
			}
			System.out.println(result);
			System.out.println(json);
			// 关闭流
			is.close();
			// 断开连接，disconnect是在底层tcp socket链接空闲时才切断，如果正在被其他线程使用就不切断。
			conn.disconnect();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 以get方式调用对方接口方法
	 * 
	 * @param pathUrl
	 */
	public static void doGet(String pathUrl) {
		BufferedReader br = null;
		String result = "";
		try {
			URL url = new URL(pathUrl);

			// 打开和url之间的连接
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			// 设定请求的方法为"GET"，默认是GET
			// post与get的不同之处在于post的参数不是放在URL字串里面，而是放在http请求的正文内。
			conn.setRequestMethod("GET");

			// 设置30秒连接超时
			conn.setConnectTimeout(30000);
			// 设置30秒读取超时
			conn.setReadTimeout(30000);

			// 设置是否向httpUrlConnection输出，因为这个是post请求，参数要放在http正文内，因此需要设为true, 默认情况下是false;
			conn.setDoOutput(true);
			// 设置是否从httpUrlConnection读入，默认情况下是true;
			conn.setDoInput(true);

			// Post请求不能使用缓存(get可以不使用)
			conn.setUseCaches(false);

			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive"); // 维持长链接
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
			// 必须要有的身份认证参数 在组织 界面 钉钉右上角 我的头像点击 后 系统管理》系统集成中有这两个字段
			conn.setRequestProperty("EngineCode", "fs1tkeu2ap4kb4hp");
			conn.setRequestProperty("EngineSecret", "Ed0JouQbydoe1seTTuETeqK7VbJqTX2jEWOUCnnfgZc0kzLg18nZFw==");
			// 连接，从上述url.openConnection()至此的配置必须要在connect之前完成，
			conn.connect();

			/**
			 * 下面的代码相当于，获取调用第三方http接口后返回的结果
			 */
			// 获取URLConnection对象对应的输入流
			InputStream is = conn.getInputStream();
			// 构造一个字符流缓存
			br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			String str = "";
			while ((str = br.readLine()) != null) {
				result += str;
			}
			System.out.println(result);
			// 关闭流
			is.close();
			// 断开连接，disconnect是在底层tcp socket链接空闲时才切断，如果正在被其他线程使用就不切断。
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null) {
					br.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
