module Demo {
	requires json.lib;
	requires org.json;
}